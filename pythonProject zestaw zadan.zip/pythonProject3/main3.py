def funkcja():
    for x in range(10):
        liczba = 304 + x * 10
        if liczba % 6 == 0 and liczba % 9 != 0:
            print(x)

print(funkcja())
