x = input()
suma = int(x[0]) + int(x[-1])
print(suma)
print(int(x) % suma)